import {Hero} from './hero';

export const HEROES: Hero[] = [
  { id: 11, name: 'Dr Ice' },
  { id: 12, name: 'Galaxy Walker' },
  { id: 13, name: 'Bongo' },
  { id: 14, name: 'EggWhites' },
  { id: 15, name: 'Magneta' },
  { id: 16, name: 'RubberWoman' },
  { id: 17, name: 'X-ray' },
  { id: 18, name: 'Dr IQ' },
  { id: 19, name: 'Magma' },
  { id: 20, name: 'Hurricane' }
];
